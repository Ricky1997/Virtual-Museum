﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectData : MonoBehaviour {

	private List<string> AboutObject = new List<string>();

	public string ReadData(int index){
		if (index >= 0 && index < AboutObject.Count) {
			return AboutObject [index];
		}
		return "";
	}
	public void WriteData(string Data ){

		AboutObject.Add (Data);
	}


}
